## Software Architecture

Here is some information about the software architecture of the Internet Banking System...

![](embed:Containers)

### Web Application
...

### Database
...

Here is some information about the API Application...

![](embed:Components)

### Sign in process

Here is some information about the Sign In Controller, including how the sign in process works...

![](embed:SignIn)
## Context

Here is some context about the Internet Banking System...

![](embed:SystemContext)

### Internet Banking System
...

### Mainframe Banking System
...
